# recommendations/views.py
from django.shortcuts import render
from .recommender import get_recommends  # Import the recommendation function

def book_search(request):
    recommendations = None
    searched_book = None

    if request.method == 'GET' and 'book_name' in request.GET:
        searched_book = request.GET['book_name']
        recommendations = get_recommends(searched_book)  # Call the recommender function

    return render(request, 'recommendations/book_search.html', {
        'searched_book': searched_book,
        'recommendations': recommendations
    })
