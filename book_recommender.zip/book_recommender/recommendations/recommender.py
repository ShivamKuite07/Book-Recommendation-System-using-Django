from re import search
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors
import warnings

warnings.filterwarnings('ignore')
pd.set_option('display.max_colwidth', None)

# Load data for books and ratings
df_books = pd.read_csv('../Dataset/Books.csv')
df_ratings = pd.read_csv('../Dataset/Ratings.csv')

# Remove unnecessary columns and keep only required fields
df_books = df_books[['ISBN', 'Book-Title', 'Book-Author', 'Year-Of-Publication', 'Image-URL-M', 'Image-URL-L']]

# Drop null values in books dataframe
df_books.dropna(inplace=True)

# Filter out users with fewer than 200 ratings
user_ratings_count = df_ratings['User-ID'].value_counts()
df_ratings_rm = df_ratings[~df_ratings['User-ID'].isin(user_ratings_count[user_ratings_count < 200].index)]

# Filter out books with fewer than 100 ratings
book_ratings_count = df_ratings['ISBN'].value_counts()
df_ratings_rm = df_ratings_rm[~df_ratings_rm['ISBN'].isin(book_ratings_count[book_ratings_count < 100].index)]

# Create a pivot table for collaborative filtering
df = df_ratings_rm.pivot_table(index='User-ID', columns='ISBN', values='Book-Rating').fillna(0).T
df.index = df.join(df_books.set_index('ISBN'))['Book-Title']
df = df.sort_index()

# Create and fit the KNN model
model = NearestNeighbors(metric='cosine')
model.fit(df.values)




# def get_recommends(title=""):
#     # Find the closest title match using fuzzy matching
#     closest_title, score = process.extractOne(title, df.index, score_cutoff=75)  # Adjust score_cutoff as needed
    
#     if not closest_title:
#         print(f"No close match found for '{title}' in the database.")
#         return {'error': 'Book not found'}
    
#     print(f"Using closest match: '{closest_title}' with a score of {score}")
    
#     # Locate the book in the pivot table
#     book = df.loc[closest_title]
    
#     # Get the nearest neighbors
#     distances, indices = model.kneighbors([book.values], n_neighbors=6)
    
#     # Fetch recommended books with required details
#     recommended_books = []
#     for idx in indices[0][1:]:  # Skip the first item as it is the queried book itself
#         recommended_title = df.index[idx]
#         book_info = df_books[df_books['Book-Title'] == recommended_title].iloc[0]
#         recommended_books.append({
#             'Book_Title': book_info['Book-Title'],
#             'Book_Author': book_info['Book-Author'],
#             'Year_Of_Publication': book_info['Year-Of-Publication'],
#             'Image_URL_M': book_info['Image-URL-M'],
#             'Image_URL_L': book_info['Image-URL-L']
#         })

#     return {
#         'searched_book': closest_title,
#         'recommended_books': recommended_books
#     }

# Example usage
# books = get_recommends("Queen of the Damned")
# print(books)


# to match the name 0.75 
from fuzzywuzzy import process


from fuzzywuzzy import process

def get_recommends(title=""):
    try:
        # Find the closest title match using fuzzy matching
        closest_title, score = process.extractOne(title, df.index, score_cutoff=75)  # Adjust score_cutoff as needed
        
        if not closest_title:
            print(f"No close match found for '{title}' in the database.")
            return {'error': 'Book not found'}
        
        print(f"Using closest match: '{closest_title}' with a score of {score}")
        
        # Locate the book in the pivot table
        book = df.loc[closest_title]
        
        # Get the nearest neighbors
        distances, indices = model.kneighbors([book.values], n_neighbors=6)
        
        # Fetch recommended books with required details
        recommended_books = []
        for idx in indices[0][1:]:  # Skip the first item as it is the queried book itself
            recommended_title = df.index[idx]
            book_info = df_books[df_books['Book-Title'] == recommended_title].iloc[0]
            recommended_books.append({
                'Book_Title': book_info['Book-Title'],
                'Book_Author': book_info['Book-Author'],
                'Year_Of_Publication': book_info['Year-Of-Publication'],
                'Image_URL_M': book_info['Image-URL-M'],
                'Image_URL_L': book_info['Image-URL-L']
            })
        
        return {
            'searched_book': closest_title,
            'recommended_books': recommended_books
        }

    except Exception as e:
        print(f"An error occurred: {e}")
        return {'error': 'Book not found'}
